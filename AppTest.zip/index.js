var express = require('express');
var sqlite3 = require('sqlite3').verbose();
var path = require('path');
var bodyParser = require('body-parser');

//Creating express server

var app = express();

//Server configuration

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({extended:false}));

//GET /

app.get('/', (req, res) => {
    res.redirect('/books');
});

//Setting up name 

var db_name = path.join(__dirname, 'data', 'apptest.db');

var db = new sqlite3.Database(db_name, err => {
    if(err){
        return console.error(err.message);
    }

    console.log('Successfully connected to database::::"apptest.db"');
});

app.get('/books', (req, res) => {
    var sql_get_books = `SELECT * FROM Books ORDER BY Author`;
    db.all(sql_get_books, [], (err, rows) => {
        if(err){
            return console.error(err.message);
        }

        res.render('books', {model:rows})
    });
});

app.get('/edit/:id', (req, res) => {
    const id = req.params.id;
    const sql = `SELECT * FROM Books WHERE Book_ID = ?`;
    db.get(sql, id, (err, rows) => {
        if(err){
            return console.error(err.message);
        }

        res.render('edit', {model:rows})
    });
});

app.post('/edit/:id', (req, res) => {
    const id = req.params.id;
    const book = [req.body.Title, req.body.Author, id];
    const sql = `UPDATE Books SET Title = ?, Author = ? WHERE (Book_ID = ?)`;
    db.run(sql, book, err => {
        if(err){
            console.error(err.message);
        }

        res.redirect('/books');
        console.log(`UPDATED RECORD:::::${book}`);
    });
});

app.get('/create', (req, res) => {
    res.render('create', {model:{}});
});

app.post('/create', (req, res) => {
    const sql = `INSERT INTO Books (Title, Author) VALUES (?, ?)`;
    const book = [req.body.Title, req.body.Author];
    db.run(sql, book, err => {
        if(err){
            console.error(err);
        }

        res.redirect('/books');
        console.log(`ADDED RECORD::::${book}`);
    });
});

app.get('/delete/:id', (req, res) => {
    const id = req.params.id;
    const sql = `SELECT * FROM Books WHERE Book_ID = ?`;
    db.get(sql, id, (err, row) => {
        if(err){
            console.error(err.message);
        }

        res.render('delete', {model:row});
    });
});

app.post('/delete/:id', (req, res) => {
    const id = req.params.id;
    const book = [req.body.Title, req.body.Author];
    const sql = `DELETE FROM Books WHERE Book_ID = ?`;
    db.run(sql, id, err => {
        if(err){
            console.error(err);
        }

        res.redirect('/books');
        console.log(`DELETED RECORD::::${book}`);
    })
})

//Starting the server

app.listen(3000, () => {
    console.log('Server started:::::::::::(http://localhost:3000)')
})